import java.util.Scanner;

public class Ejercicio15 {

    public static int[] generarFibonacci(int cantidad) {
        int[] fibo = new int[cantidad];
        fibo[0] = 0;
        fibo[1] = 1;
        for (int i = 2; i < cantidad; i++) {
            fibo[i] = fibo[i - 1] + fibo[i - 2];
        }
        return fibo;
    }

    public static boolean perteneceAFibonacci(int numero, int[] fibo) {
        for (int i = 0; i < fibo.length; i++) {
            if (numero == fibo[i]) {
                return true;
            }
        }
        return false;
    }

    public static void verificarFibonacci() {
        Scanner teclado = new Scanner(System.in);
        int[] numeros = new int[10];
        int[] fibo = generarFibonacci(100);
        int contador = 0;

        for (int i = 0; i < 10; i++) {
            System.out.print("ingrese número " + (i + 1) + ": ");
            numeros[i] = teclado.nextInt();
            if (perteneceAFibonacci(numeros[i], fibo)) {
                contador++;
            }
        }

        System.out.println("cantidad de números que pertenecen a los primeros 100 de la serie de Fibonacci: " + contador);
    }

    public static void main(String[] args) {
        verificarFibonacci();
    }
}
