import java.util.Scanner;

public class Ejercicio12 {

    
    public static void calcularEdadFutura(int añosActual, int mesesActual, int diasActual, int n) {
        int añosFuturos = añosActual + n;
        int mesesFuturos = mesesActual;
        int diasFuturos = diasActual;

        System.out.println("Dentro de " + n + " años, tendrás:");
        System.out.println(añosFuturos + " años, " + mesesFuturos + " meses, y " + diasFuturos + " días.");
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Ingrese su edad actual en años: ");
        int años = teclado.nextInt();

        System.out.print("Ingrese meses adicionales: ");
        int meses = teclado.nextInt();

        System.out.print("Ingrese días adicionales: ");
        int dias = teclado.nextInt();

        System.out.print("Ingrese cuántos años en el futuro desea calcular su edad: ");
        int n = teclado.nextInt();

        calcularEdadFutura(años, meses, dias, n);
    }
}
