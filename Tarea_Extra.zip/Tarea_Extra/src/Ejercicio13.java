import java.util.Scanner;

public class Ejercicio13 {

    public static double areaTriangulo(double base, double altura) {
        return (base * altura) / 2;
    }

    public static double areaCuadrado(double lado) {
        return lado * lado;
    }

    public static double areaCubo(double lado) {
        return 6 * lado * lado;
    }

    public static double areaRectangulo(double base, double altura) {
        return base * altura;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.println("triángulo:");
        System.out.print("ingrese base: ");
        double baseTriangulo = teclado.nextDouble();
        System.out.print("ingrese altura: ");
        double alturaTriangulo = teclado.nextDouble();
        double areaTri = Math.round(areaTriangulo(baseTriangulo, alturaTriangulo) * 100.0) / 100.0;
        System.out.println("área del triángulo: " + areaTri);
        System.out.println();

        System.out.println("cuadrado:");
        System.out.print("ingrese lado: ");
        double ladoCuadrado = teclado.nextDouble();
        double areaCuad = Math.round(areaCuadrado(ladoCuadrado) * 100.0) / 100.0;
        System.out.println("área del cuadrado: " + areaCuad);
        System.out.println();

        System.out.println("cubo:");
        System.out.print("ingrese lado: ");
        double ladoCubo = teclado.nextDouble();
        double areaCub = Math.round(areaCubo(ladoCubo) * 100.0) / 100.0;
        System.out.println("área superficial del cubo: " + areaCub);
        System.out.println();

        System.out.println("rectángulo:");
        System.out.print("ingrese base: ");
        double baseRectangulo = teclado.nextDouble();
        System.out.print("ingrese altura: ");
        double alturaRectangulo = teclado.nextDouble();
        double areaRec = Math.round(areaRectangulo(baseRectangulo, alturaRectangulo) * 100.0) / 100.0;
        System.out.println("área del rectángulo: " + areaRec);
    }
}
