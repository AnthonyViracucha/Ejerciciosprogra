import java.util.Random;

public class Ejercicio20 {

    public static void llenarMatriz(int[][] matriz, Random aleatorio) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz[i][j] = aleatorio.nextInt(100) + 1; // valores entre 1 y 100
            }
        }
    }

    public static void mostrarMatriz(int[][] matriz) {
        System.out.println("matriz generada:");
        for (int[] fila : matriz) {
            for (int valor : fila) {
                System.out.print(valor + "\t");
            }
            System.out.println();
        }
    }

    public static void encontrarMayorMultiplo8(int[][] matriz) {
        int mayor = -1;
        int fila = -1;
        int columna = -1;

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                if (matriz[i][j] % 8 == 0 && matriz[i][j] > mayor) {
                    mayor = matriz[i][j];
                    fila = i;
                    columna = j;
                }
            }
        }

        if (mayor != -1) {
            System.out.println("mayor múltiplo de 8: " + mayor);
            System.out.println("posición: fila " + fila + ", columna " + columna);
        } else {
            System.out.println("no se encontró ningún múltiplo de 8 en la matriz.");
        }
    }

    public static void main(String[] args) {
        int[][] matriz = new int[5][5];
        Random aleatorio = new Random();

        llenarMatriz(matriz, aleatorio);
        mostrarMatriz(matriz);
        encontrarMayorMultiplo8(matriz);
    }
}
