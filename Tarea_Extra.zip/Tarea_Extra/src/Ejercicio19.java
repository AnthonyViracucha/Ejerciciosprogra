import java.util.Scanner;

public class Ejercicio19{

    public static boolean esPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }

    public static void contarPrimosTerminanEn3() {
        Scanner teclado = new Scanner(System.in);
        int[][] matriz = new int[3][4];
        int contador = 0;

        System.out.println("ingrese los valores de la matriz 3x4:");

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print("matriz[" + i + "][" + j + "]: ");
                matriz[i][j] = teclado.nextInt();
            }
        }

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                int num = matriz[i][j];
                if (esPrimo(num) && num % 10 == 3) {
                    contador++;
                }
            }
        }

        System.out.println("cantidad de números primos que terminan en 3: " + contador);
    }

    public static void main(String[] args) {
        contarPrimosTerminanEn3();
    }
}
