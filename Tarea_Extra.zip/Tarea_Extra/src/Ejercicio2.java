import java.util.Scanner;

public class Ejercicio2 {

    public static double hallarX(double radio, double angulo) {
        return radio * Math.cos(angulo);
    }

    public static double hallarY(double radio, double angulo) {
        return radio * Math.sin(angulo);
    }


    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese el radio: ");
        double radio = teclado.nextDouble();
        System.out.print("Ingrese el ángulo en radianes: ");
        double angulo = teclado.nextDouble();
        double x = hallarX(radio, angulo);
        double y = hallarY(radio, angulo);
        System.out.println("Coordenada X: " + x);
        System.out.println("Coordenada Y: " + y);
    }
}