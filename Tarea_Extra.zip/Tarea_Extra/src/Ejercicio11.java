import java.util.Scanner;

public class Ejercicio11 {

    public static double calcularPerimetro(double a, double b, double c) {
        return a + b + c;
    }

    public static double calcularArea(double a, double b, double c) {
        double s = (a + b + c) / 2.0;
        return Math.sqrt(s * (s - a) * (s - b) * (s - c));
    }

    public static boolean esTrianguloValido(double a, double b, double c) {
        return (a + b > c) && (a + c > b) && (b + c > a);
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.println("Ingrese los lados del triángulo:");
        System.out.print("Lado a: ");
        double a = teclado.nextDouble();
        System.out.print("Lado b: ");
        double b = teclado.nextDouble();
        System.out.print("Lado c: ");
        double c = teclado.nextDouble();

        if (esTrianguloValido(a, b, c)) {
            double perimetro = calcularPerimetro(a, b, c);
            double area = calcularArea(a, b, c);

            System.out.println("Perímetro: " + perimetro);
            System.out.println("Área: " + area);

        } else {
            System.out.println("Los lados ingresados no forman un triángulo válido.");
        }
    }
}
