import java.util.Scanner;

public class Ejercicio10 {

    
    public static boolean esPerfecto(int num) {
        if (num <= 1) {
            return false;
        }
        int sumaDivisores = 1; 
        for (int i = 2; i <= num / 2; i++) {
            if (num % i == 0) {
                sumaDivisores += i;
            }
        }
        return sumaDivisores == num;
    }

    public static void mostrarNumerosPerfectos(int n) {
        int contador = 0;
        int numero = 2; 
        while (contador < n) {
            if (esPerfecto(numero)) {
                System.out.println("Número perfecto #" + (contador + 1) + ": " + numero);
                contador++;
            }
            numero++;
        }
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese cuántos números perfectos desea encontrar: ");
        int n = teclado.nextInt();

        mostrarNumerosPerfectos(n);
    }
}
