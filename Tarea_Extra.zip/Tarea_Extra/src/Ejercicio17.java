import java.util.Scanner;

public class Ejercicio17 {

    public static void verificarsumaPar() {
        Scanner teclado = new Scanner(System.in);
        int[] numeros = new int[10];

        for (int i = 0; i < 10; i++) {
            System.out.print("ingrese número " + (i + 1) + ": ");
            numeros[i] = teclado.nextInt();
        }

        int menor = numeros[0];
        int mayor = numeros[0];

        for (int i = 1; i < 10; i++) {
            if (numeros[i] < menor) {
                menor = numeros[i];
            }
            if (numeros[i] > mayor) {
                mayor = numeros[i];
            }
        }

        int semisuma = (mayor + menor) / 2;

        System.out.println("valor menor: " + menor);
        System.out.println("valor mayor: " + mayor);
        System.out.println("semisuma: " + semisuma);

        if (semisuma % 2 == 0) {
            System.out.println("la semisuma es un número par");
        } else {
            System.out.println("la semisuma no es un número par");
        }
    }

    public static void main(String[] args) {
        verificarsumaPar();
    }
}
