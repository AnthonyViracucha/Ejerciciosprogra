import java.util.Arrays;
import java.util.Scanner;

public class Ejercicio6 {

   
    public static void llenarVector(double[] vector, String nombre) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Llenando vector " + nombre);
        for (int i = 0; i < vector.length; i++) {
            System.out.print(nombre + "[" + i + "]: ");
            vector[i] = teclado.nextDouble();
        }
    }

 
    public static double[] unir(double[] a, double[] b) {
        int total = a.length + b.length;
        double[] c = new double[total];

       
        for (int i = 0; i < a.length; i++) {
            c[i] = a[i];
        }

        for (int i = 0; i < b.length; i++) {
            c[a.length + i] = b[i];
        }

       
        Arrays.sort(c);
        return c;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Ingrese el tamaño del vector A: ");
        int n = teclado.nextInt();
        double[] a = new double[n];
        llenarVector(a, "A");

      
        System.out.print("Ingrese el tamaño del vector B: ");
        int m = teclado.nextInt();
        double[] b = new double[m];
        llenarVector(b, "B");

        
        double[] c = unir(a, b);

        // Mostrar vector C
        System.out.println("Vector C (unido y ordenado):");
        for (int i = 0; i < c.length; i++) {
            System.out.println("C[" + i + "] = " + c[i]);
        }
    }
}
