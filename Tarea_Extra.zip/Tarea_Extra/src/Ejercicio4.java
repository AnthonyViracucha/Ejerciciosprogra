import java.util.Scanner;

public class Ejercicio4{

    public static void motilarOvejas() {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese la cantidad de ovejas: ");
        int m = teclado.nextInt();

        double totalLana = 0;

        for (int i = 1; i <= m; i++) {
            System.out.print("Código de la oveja " + i + ": ");
            String codigo = teclado.next();
            System.out.print("Cantidad de lana de " + codigo + " (kg): ");
            double lana = teclado.nextDouble();
            System.out.println("Código: " + codigo + " - Lana: " + lana + " kg");
            totalLana += lana;
        }

        System.out.println("Total de lana obtenida: " + totalLana + " kg");
    }

    public static void main(String[] args) {
        motilarOvejas();
    }
}
